from flask import Flask, render_template, jsonify, request
app = Flask(__name__)

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client.dbsparta

@app.route('/')
def home():
    return render_template('homework-4.html')

@app.route('/orders', methods=['POST'])
def write_order():
   name_receive = request.form['name_give']
   count_receive = request.form['count_give']
   phone_receive = request.form['phone_give']
   address_receive = request.form['address_give']

   order = {
      'name': name_receive,
      'count': count_receive,
      'phone': phone_receive,
      'address': address_receive
   }
   # orders에 order 저장하기
   db.orders.insert_one(order)
   #   성공 여부 & 성공 메시지 반환
   return jsonify({'result': 'success', 'msg': '주문이 성공적으로 저장되었습니다.'})


@app.route('/orders', methods=['GET'])
def read_orders():
	# DB에서 주문 정보 모두 가져오기
    orders = list(db.orders.find({},{'_id':0}))
	# 성공 여부 & 주문 목록 반환하기
    return jsonify({'result': 'success', 'orders': orders})


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)